<?php
$_['text_foto'] = 'Фотография';
$_['text_name'] = 'Наименование';
$_['text_manufacturer'] = 'Бренд';
$_['text_quantity'] = 'Кол-во';
$_['text_price'] = 'Стоимость';
$_['text_total'] = 'Итого: ';
$_['text_empty'] = 'В вашей корзине пусто!';
$_['text_in_stock'] = 'На нашем складе';
$_['text_left'] = 'осталось';
$_['text_left1'] = 'осталась';
$_['text_just'] = 'всего';
$_['text_pcs'] = 'шт.';
?>