<?php
// Heading
$_['heading_title']    = 'Блог Статьи';

$_['text_module']      = 'Модуль';
$_['text_success']     = 'Успешно!';
$_['text_edit']        = 'Редактировать';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав!';