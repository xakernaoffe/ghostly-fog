<?php
// Heading
$_['heading_title'] 	= 'Новости';
 
// Text
$_['text_title'] 		= 'Title';
$_['text_description'] 	= 'Description';
$_['text_date'] 		= 'Date Added';
$_['text_view'] 		= 'View';
$_['text_error'] 		= 'Ничего нет';