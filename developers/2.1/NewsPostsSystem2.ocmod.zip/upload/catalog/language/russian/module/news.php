<?php
// Heading 
$_['heading_title']    = 'Последние новости';
