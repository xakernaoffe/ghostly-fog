<?php
$_['heading_title'] = 'Shopunity';
$_['text_edit'] = 'Connect to shopunity.net';
$_['button_connect'] = 'Connect';