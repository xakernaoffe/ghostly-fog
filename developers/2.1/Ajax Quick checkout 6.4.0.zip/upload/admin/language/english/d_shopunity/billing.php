<?php
$_['heading_title'] = 'Shopunity';
$_['text_edit'] = 'Extensions';

$_['tab_order'] = 'Orders';
$_['tab_invoice'] = 'Invoices';
$_['tab_transaction'] = 'Transactions';


$_['text_invoice_status_0'] = '<span class="label label-danger">Not paid</span>';
$_['text_invoice_status_1'] = '<span class="label label-success">Paid</span>';
$_['text_invoice_status_2'] = '<span class="label label-default">Canceled</span>';
$_['text_invoice_status_3'] = '<span class="label label-info">Refuning</span>';
$_['text_invoice_status_4'] = '<span class="label label-warning">Refunded</span>';

$_['text_statu_0'] = 'Iactive';
$_['text_statu_1'] = 'Active';