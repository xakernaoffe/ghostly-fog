<?php
// Text
$_['text_title'] = 'Delivery Plus';

$_['text_free'] = 'free';

$_['error_description_zone']        = '<span style="color:red;">This way of delivery is inaccessible in the chosen region.</span>';
$_['error_description_quantity']    = '<span style="color:red;">This payment method is not available, because the order has items that are not in stock.</span>';
$_['error_description_total']       = '<span style="color:red;">Min cost of the order for this type of departure is %s that it became available, add to basket goods cost %s</span>';
$_['error_description_weight']      = '<span style="color:red;">Max weight for this method of delivery %s, to become available, remove products from the basket weight %s</span>';

?>